
 thymeleaf-spring
 ----------------

This repository contains:

   * thymeleaf-spring3: Thymeleaf integration package for Spring 3.x
   * thymeleaf-spring4: Thymeleaf integration package for Spring 4.x
   * thymeleaf-spring5: Thymeleaf integration package for Spring 5.x
 
To learn more and download latest version:
 
     http://www.thymeleaf.org


     
