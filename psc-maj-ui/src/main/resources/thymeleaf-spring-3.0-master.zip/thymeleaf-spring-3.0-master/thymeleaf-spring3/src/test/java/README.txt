Tests live at the "thymeleaf-tests" repository in
https://github.com/thymeleaf/thymeleaf-tests
